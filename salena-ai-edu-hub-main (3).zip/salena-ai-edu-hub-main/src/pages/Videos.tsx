
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardHeader, CardContent, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { 
  Play, 
  Search, 
  Filter, 
  Clock, 
  Star,
  BookOpen,
  Calculator,
  Atom,
  Globe,
  Languages,
  Palette
} from 'lucide-react';
import Navbar from '@/components/Navbar';

interface Video {
  id: string;
  title: string;
  description: string;
  duration: string;
  thumbnail: string;
  category: string;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  rating: number;
  views: string;
}

const Videos = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [userName, setUserName] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const storedName = localStorage.getItem('userName');
    if (!storedName) {
      navigate('/');
      return;
    }
    setUserName(storedName);
  }, [navigate]);

  const categories = [
    { name: 'All', icon: BookOpen, color: 'gray' },
    { name: 'Mathematics', icon: Calculator, color: 'blue' },
    { name: 'Science', icon: Atom, color: 'green' },
    { name: 'History', icon: Globe, color: 'yellow' },
    { name: 'Languages', icon: Languages, color: 'purple' },
    { name: 'Arts', icon: Palette, color: 'pink' }
  ];

  const videos: Video[] = [
    {
      id: '1',
      title: 'Introduction to Algebra - Linear Equations',
      description: 'Master the fundamentals of linear equations with step-by-step examples',
      duration: '15:30',
      thumbnail: 'https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=400&h=225&fit=crop',
      category: 'Mathematics',
      difficulty: 'Beginner',
      rating: 4.8,
      views: '12.5K'
    },
    {
      id: '2',
      title: 'Physics: Understanding Motion and Forces',
      description: 'Explore the principles of motion, velocity, and Newton\'s laws',
      duration: '22:45',
      thumbnail: 'https://images.unsplash.com/photo-1636466497217-26a8cbeaf0aa?w=400&h=225&fit=crop',
      category: 'Science',
      difficulty: 'Intermediate',
      rating: 4.9,
      views: '8.3K'
    },
    {
      id: '3',
      title: 'World War II: Key Events and Impact',
      description: 'Comprehensive overview of WWII timeline and historical significance',
      duration: '18:20',
      thumbnail: 'https://images.unsplash.com/photo-1541963463532-d68292c34d19?w=400&h=225&fit=crop',
      category: 'History',
      difficulty: 'Intermediate',
      rating: 4.7,
      views: '15.2K'
    },
    {
      id: '4',
      title: 'Spanish Grammar: Present Tense Mastery',
      description: 'Learn Spanish present tense conjugation with practical examples',
      duration: '12:15',
      thumbnail: 'https://images.unsplash.com/photo-1434030216411-0b793f4b4173?w=400&h=225&fit=crop',
      category: 'Languages',
      difficulty: 'Beginner',
      rating: 4.6,
      views: '9.7K'
    },
    {
      id: '5',
      title: 'Chemistry: Atomic Structure Explained',
      description: 'Deep dive into atoms, electrons, and chemical bonding',
      duration: '25:10',
      thumbnail: 'https://images.unsplash.com/photo-1532187863486-abf9dbad1b69?w=400&h=225&fit=crop',
      category: 'Science',
      difficulty: 'Advanced',
      rating: 4.8,
      views: '6.1K'
    },
    {
      id: '6',
      title: 'Art History: Renaissance Masters',
      description: 'Explore the works of Leonardo, Michelangelo, and Raphael',
      duration: '20:30',
      thumbnail: 'https://images.unsplash.com/photo-1541961017774-22349e4a1262?w=400&h=225&fit=crop',
      category: 'Arts',
      difficulty: 'Beginner',
      rating: 4.5,
      views: '7.8K'
    }
  ];

  const filteredVideos = videos.filter(video => {
    const matchesSearch = video.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         video.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || video.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Beginner': return 'bg-green-100 text-green-800';
      case 'Intermediate': return 'bg-yellow-100 text-yellow-800';
      case 'Advanced': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <div className="container mx-auto px-6 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Video Library</h1>
          <p className="text-gray-600">Curated educational content for enhanced learning</p>
        </div>

        {/* Search and Filter */}
        <div className="mb-8 space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search videos..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>

          <div className="flex flex-wrap gap-2">
            {categories.map((category) => (
              <Button
                key={category.name}
                variant={selectedCategory === category.name ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedCategory(category.name)}
                className={`flex items-center space-x-2 ${
                  selectedCategory === category.name 
                    ? 'bg-blue-600 text-white' 
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                <category.icon className="h-4 w-4" />
                <span>{category.name}</span>
              </Button>
            ))}
          </div>
        </div>

        {/* Video Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredVideos.map((video) => (
            <Card key={video.id} className="hover:shadow-lg transition-all duration-200 cursor-pointer group border-0 shadow-md">
              <div className="relative">
                <img
                  src={video.thumbnail}
                  alt={video.title}
                  className="w-full h-48 object-cover rounded-t-lg"
                />
                <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity duration-200 rounded-t-lg flex items-center justify-center">
                  <div className="bg-white/90 rounded-full p-3">
                    <Play className="h-6 w-6 text-blue-600" />
                  </div>
                </div>
                <div className="absolute bottom-2 right-2 bg-black/80 text-white text-xs px-2 py-1 rounded">
                  {video.duration}
                </div>
              </div>
              
              <CardContent className="p-4">
                <div className="flex items-start justify-between mb-2">
                  <Badge variant="secondary" className={getDifficultyColor(video.difficulty)}>
                    {video.difficulty}
                  </Badge>
                  <div className="flex items-center space-x-1 text-sm text-gray-500">
                    <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                    <span>{video.rating}</span>
                  </div>
                </div>
                
                <h3 className="font-semibold text-gray-900 mb-2 line-clamp-2">
                  {video.title}
                </h3>
                
                <p className="text-sm text-gray-600 mb-3 line-clamp-2">
                  {video.description}
                </p>
                
                <div className="flex items-center justify-between text-xs text-gray-500">
                  <span>{video.category}</span>
                  <span>{video.views} views</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredVideos.length === 0 && (
          <div className="text-center py-12">
            <BookOpen className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No videos found</h3>
            <p className="text-gray-600">Try adjusting your search or filter criteria</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Videos;
