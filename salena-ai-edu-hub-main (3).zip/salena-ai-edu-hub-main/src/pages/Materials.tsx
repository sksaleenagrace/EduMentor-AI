
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardHeader, CardContent, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/components/ui/use-toast';
import { 
  BookOpen, 
  Download, 
  Search, 
  FileText, 
  Image, 
  FileQuestion,
  Calculator,
  Atom,
  Globe,
  Languages,
  Palette,
  Star,
  MessageCircle,
  Bot,
  Music,
  Code,
  Heart,
  TrendingUp,
  Zap
} from 'lucide-react';
import Navbar from '@/components/Navbar';

interface Material {
  id: string;
  title: string;
  description: string;
  type: 'PDF' | 'Notes' | 'Quiz' | 'Worksheet';
  category: string;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  rating: number;
  downloads: string;
  fileSize?: string;
}

const Materials = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedType, setSelectedType] = useState('All');
  const [userName, setUserName] = useState('');
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    const storedName = localStorage.getItem('userName');
    if (!storedName) {
      navigate('/');
      return;
    }
    setUserName(storedName);
  }, [navigate]);

  const categories = [
    { name: 'All', icon: BookOpen },
    { name: 'Mathematics', icon: Calculator },
    { name: 'Science', icon: Atom },
    { name: 'History', icon: Globe },
    { name: 'Languages', icon: Languages },
    { name: 'Arts', icon: Palette },
    { name: 'Music', icon: Music },
    { name: 'Programming', icon: Code },
    { name: 'Biology', icon: Heart },
    { name: 'Economics', icon: TrendingUp }
  ];

  const materialTypes = ['All', 'PDF', 'Notes', 'Quiz', 'Worksheet'];

  const materials: Material[] = [
    // Mathematics
    {
      id: '1',
      title: 'Algebra Fundamentals Guide',
      description: 'Complete guide covering linear equations, quadratic functions, and polynomials',
      type: 'PDF',
      category: 'Mathematics',
      difficulty: 'Beginner',
      rating: 4.8,
      downloads: '2.3K',
      fileSize: '2.5 MB'
    },
    {
      id: '7',
      title: 'Calculus Practice Problems',
      description: 'Challenging calculus problems with step-by-step solutions',
      type: 'Worksheet',
      category: 'Mathematics',
      difficulty: 'Advanced',
      rating: 4.9,
      downloads: '1.6K',
      fileSize: '2.8 MB'
    },
    {
      id: '15',
      title: 'Geometry Interactive Quiz',
      description: 'Test your knowledge of shapes, angles, and geometric theorems',
      type: 'Quiz',
      category: 'Mathematics',
      difficulty: 'Intermediate',
      rating: 4.7,
      downloads: '1.9K'
    },
    // Science
    {
      id: '2',
      title: 'Physics Formula Sheet',
      description: 'Essential formulas for mechanics, thermodynamics, and electromagnetism',
      type: 'Notes',
      category: 'Science',
      difficulty: 'Intermediate',
      rating: 4.9,
      downloads: '1.8K',
      fileSize: '1.2 MB'
    },
    {
      id: '5',
      title: 'Chemistry Periodic Table Study Guide',
      description: 'Comprehensive guide to elements, properties, and chemical reactions',
      type: 'PDF',
      category: 'Science',
      difficulty: 'Advanced',
      rating: 4.8,
      downloads: '990',
      fileSize: '4.2 MB'
    },
    // Biology
    {
      id: '16',
      title: 'Human Anatomy Atlas',
      description: 'Detailed diagrams and explanations of human body systems',
      type: 'PDF',
      category: 'Biology',
      difficulty: 'Intermediate',
      rating: 4.6,
      downloads: '2.1K',
      fileSize: '5.8 MB'
    },
    {
      id: '17',
      title: 'Cell Biology Worksheets',
      description: 'Practice exercises on cell structure and functions',
      type: 'Worksheet',
      category: 'Biology',
      difficulty: 'Beginner',
      rating: 4.5,
      downloads: '1.7K',
      fileSize: '2.2 MB'
    },
    // History
    {
      id: '3',
      title: 'World War II Timeline Quiz',
      description: 'Interactive quiz covering major events and dates of WWII',
      type: 'Quiz',
      category: 'History',
      difficulty: 'Intermediate',
      rating: 4.6,
      downloads: '1.5K'
    },
    {
      id: '8',
      title: 'Ancient Civilizations Quiz',
      description: 'Test your knowledge of ancient Egypt, Greece, and Rome',
      type: 'Quiz',
      category: 'History',
      difficulty: 'Beginner',
      rating: 4.4,
      downloads: '1.9K'
    },
    {
      id: '18',
      title: 'Renaissance Study Notes',
      description: 'Complete notes on Renaissance art, culture, and historical impact',
      type: 'Notes',
      category: 'History',
      difficulty: 'Intermediate',
      rating: 4.7,
      downloads: '1.3K',
      fileSize: '3.1 MB'
    },
    // Languages
    {
      id: '4',
      title: 'Spanish Vocabulary Worksheets',
      description: 'Practice sheets for common Spanish words and phrases',
      type: 'Worksheet',
      category: 'Languages',
      difficulty: 'Beginner',
      rating: 4.7,
      downloads: '2.1K',
      fileSize: '3.1 MB'
    },
    {
      id: '19',
      title: 'French Grammar Guide',
      description: 'Comprehensive guide to French grammar rules and conjugations',
      type: 'PDF',
      category: 'Languages',
      difficulty: 'Intermediate',
      rating: 4.8,
      downloads: '1.6K',
      fileSize: '4.0 MB'
    },
    {
      id: '20',
      title: 'English Literature Analysis',
      description: 'In-depth analysis of classic English literature works',
      type: 'Notes',
      category: 'Languages',
      difficulty: 'Advanced',
      rating: 4.6,
      downloads: '1.1K',
      fileSize: '2.9 MB'
    },
    // Arts
    {
      id: '6',
      title: 'Renaissance Art Analysis Notes',
      description: 'Detailed notes on famous Renaissance artworks and techniques',
      type: 'Notes',
      category: 'Arts',
      difficulty: 'Intermediate',
      rating: 4.5,
      downloads: '1.2K',
      fileSize: '1.8 MB'
    },
    {
      id: '21',
      title: 'Digital Art Fundamentals',
      description: 'Learn basic digital art techniques and software tools',
      type: 'PDF',
      category: 'Arts',
      difficulty: 'Beginner',
      rating: 4.7,
      downloads: '1.8K',
      fileSize: '6.2 MB'
    },
    // Programming
    {
      id: '22',
      title: 'Python Basics for Beginners',
      description: 'Complete introduction to Python programming language',
      type: 'PDF',
      category: 'Programming',
      difficulty: 'Beginner',
      rating: 4.9,
      downloads: '3.2K',
      fileSize: '4.5 MB'
    },
    {
      id: '23',
      title: 'JavaScript Practice Exercises',
      description: 'Hands-on coding exercises to master JavaScript fundamentals',
      type: 'Worksheet',
      category: 'Programming',
      difficulty: 'Intermediate',
      rating: 4.8,
      downloads: '2.7K',
      fileSize: '1.9 MB'
    },
    {
      id: '24',
      title: 'Data Structures Quiz',
      description: 'Test your understanding of arrays, stacks, queues, and trees',
      type: 'Quiz',
      category: 'Programming',
      difficulty: 'Advanced',
      rating: 4.6,
      downloads: '1.4K'
    },
    // Music
    {
      id: '25',
      title: 'Music Theory Basics',
      description: 'Fundamentals of music theory including scales, chords, and rhythm',
      type: 'PDF',
      category: 'Music',
      difficulty: 'Beginner',
      rating: 4.7,
      downloads: '1.9K',
      fileSize: '3.3 MB'
    },
    {
      id: '26',
      title: 'Piano Practice Sheets',
      description: 'Progressive exercises for developing piano skills',
      type: 'Worksheet',
      category: 'Music',
      difficulty: 'Intermediate',
      rating: 4.5,
      downloads: '1.5K',
      fileSize: '2.1 MB'
    },
    // Economics
    {
      id: '27',
      title: 'Microeconomics Study Guide',
      description: 'Complete guide to supply and demand, market structures, and consumer behavior',
      type: 'PDF',
      category: 'Economics',
      difficulty: 'Intermediate',
      rating: 4.8,
      downloads: '1.7K',
      fileSize: '3.8 MB'
    },
    {
      id: '28',
      title: 'Economics Problem Sets',
      description: 'Practice problems covering macroeconomics and microeconomics',
      type: 'Worksheet',
      category: 'Economics',
      difficulty: 'Advanced',
      rating: 4.6,
      downloads: '1.2K',
      fileSize: '2.4 MB'
    }
  ];

  const filteredMaterials = materials.filter(material => {
    const matchesSearch = material.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         material.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || material.category === selectedCategory;
    const matchesType = selectedType === 'All' || material.type === selectedType;
    return matchesSearch && matchesCategory && matchesType;
  });

  const handleDownload = (material: Material) => {
    // Simulate download process
    toast({
      title: "Download Started",
      description: `Downloading ${material.title}...`,
    });
    
    // Simulate successful download after 2 seconds
    setTimeout(() => {
      toast({
        title: "Download Complete",
        description: `${material.title} has been downloaded successfully!`,
      });
    }, 2000);
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'PDF': return FileText;
      case 'Notes': return BookOpen;
      case 'Quiz': return FileQuestion;
      case 'Worksheet': return Image;
      default: return FileText;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'PDF': return 'bg-red-100 text-red-800';
      case 'Notes': return 'bg-blue-100 text-blue-800';
      case 'Quiz': return 'bg-green-100 text-green-800';
      case 'Worksheet': return 'bg-purple-100 text-purple-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Beginner': return 'bg-green-100 text-green-800';
      case 'Intermediate': return 'bg-yellow-100 text-yellow-800';
      case 'Advanced': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <div className="container mx-auto px-6 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Study Materials</h1>
          <p className="text-gray-600">Access comprehensive learning resources and practice materials</p>
        </div>

        {/* AI Tutor Highlight Section */}
        <Card className="mb-8 bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="bg-white/20 p-3 rounded-full">
                  <Bot className="h-8 w-8 text-white" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-1">Need Help with Any Subject?</h3>
                  <p className="text-purple-100">Chat with our AI Tutor for instant explanations and personalized help!</p>
                </div>
              </div>
              <Button 
                onClick={() => navigate('/tutor')}
                className="bg-white text-purple-600 hover:bg-gray-100 font-semibold px-6 py-3 flex items-center space-x-2"
              >
                <MessageCircle className="h-5 w-5" />
                <span>Chat with AI Tutor</span>
                <Zap className="h-4 w-4" />
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Search and Filters */}
        <div className="mb-8 space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search materials..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>

          <div className="space-y-3">
            <div>
              <p className="text-sm font-medium text-gray-700 mb-2">Categories:</p>
              <div className="flex flex-wrap gap-2">
                {categories.map((category) => (
                  <Button
                    key={category.name}
                    variant={selectedCategory === category.name ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedCategory(category.name)}
                    className={`flex items-center space-x-2 ${
                      selectedCategory === category.name 
                        ? 'bg-blue-600 text-white' 
                        : 'text-gray-600 hover:text-gray-900'
                    }`}
                  >
                    <category.icon className="h-4 w-4" />
                    <span>{category.name}</span>
                  </Button>
                ))}
              </div>
            </div>

            <div>
              <p className="text-sm font-medium text-gray-700 mb-2">Material Types:</p>
              <div className="flex flex-wrap gap-2">
                {materialTypes.map((type) => (
                  <Button
                    key={type}
                    variant={selectedType === type ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedType(type)}
                    className={selectedType === type ? 'bg-purple-600 text-white' : 'text-gray-600 hover:text-gray-900'}
                  >
                    {type}
                  </Button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Materials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredMaterials.map((material) => {
            const TypeIcon = getTypeIcon(material.type);
            return (
              <Card key={material.id} className="hover:shadow-lg transition-all duration-200 cursor-pointer group border-0 shadow-md">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="bg-gray-100 p-3 rounded-full">
                      <TypeIcon className="h-6 w-6 text-gray-600" />
                    </div>
                    <div className="flex items-center space-x-1 text-sm text-gray-500">
                      <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                      <span>{material.rating}</span>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <div className="flex flex-wrap gap-2">
                      <Badge className={getTypeColor(material.type)}>
                        {material.type}
                      </Badge>
                      <Badge variant="secondary" className={getDifficultyColor(material.difficulty)}>
                        {material.difficulty}
                      </Badge>
                    </div>

                    <h3 className="font-semibold text-gray-900 line-clamp-2">
                      {material.title}
                    </h3>

                    <p className="text-sm text-gray-600 line-clamp-3">
                      {material.description}
                    </p>

                    <div className="flex items-center justify-between text-xs text-gray-500">
                      <span>{material.category}</span>
                      <span>{material.downloads} downloads</span>
                    </div>

                    {material.fileSize && (
                      <p className="text-xs text-gray-500">Size: {material.fileSize}</p>
                    )}

                    <Button 
                      className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                      onClick={() => handleDownload(material)}
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Download
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {filteredMaterials.length === 0 && (
          <div className="text-center py-12">
            <BookOpen className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No materials found</h3>
            <p className="text-gray-600">Try adjusting your search or filter criteria</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Materials;
