
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardHeader, CardContent, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { 
  GraduationCap, 
  MessageCircle, 
  Play, 
  BookOpen, 
  TrendingUp, 
  Award,
  Clock,
  Users
} from 'lucide-react';
import Navbar from '@/components/Navbar';

const Dashboard = () => {
  const [userName, setUserName] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const storedName = localStorage.getItem('userName');
    if (!storedName) {
      navigate('/');
      return;
    }
    setUserName(storedName);
  }, [navigate]);

  const quickActions = [
    {
      title: 'Chat with AI Tutor',
      description: 'Get instant help and explanations',
      icon: MessageCircle,
      color: 'blue',
      action: () => navigate('/tutor')
    },
    {
      title: 'Watch Video Lessons',
      description: 'Learn from curated content',
      icon: Play,
      color: 'red',
      action: () => navigate('/videos')
    },
    {
      title: 'Study Materials',
      description: 'Access notes and resources',
      icon: BookOpen,
      color: 'green',
      action: () => navigate('/materials')
    },
    {
      title: 'Track Progress',
      description: 'Monitor your learning journey',
      icon: TrendingUp,
      color: 'purple',
      action: () => navigate('/progress')
    }
  ];

  const recentActivity = [
    { type: 'chat', title: 'Mathematics - Algebra Help', time: '2 hours ago' },
    { type: 'video', title: 'Physics: Motion and Forces', time: '1 day ago' },
    { type: 'quiz', title: 'Chemistry Quiz - 85% Score', time: '2 days ago' },
  ];

  const learningStats = [
    { label: 'Courses Completed', value: '12', icon: Award, color: 'yellow' },
    { label: 'Hours Learned', value: '47', icon: Clock, color: 'blue' },
    { label: 'AI Conversations', value: '156', icon: MessageCircle, color: 'green' },
    { label: 'Study Streak', value: '15 days', icon: TrendingUp, color: 'purple' }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <div className="container mx-auto px-6 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Welcome back, {userName}! 👋
          </h1>
          <p className="text-gray-600 text-lg">
            Ready to continue your learning journey? Let's make today productive!
          </p>
        </div>

        {/* Learning Progress */}
        <Card className="mb-8 bg-gradient-to-r from-blue-500 to-purple-600 text-white border-0">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-xl font-semibold mb-1">Today's Learning Goal</h3>
                <p className="text-blue-100">2 hours of focused study</p>
              </div>
              <GraduationCap className="h-12 w-12 text-white opacity-80" />
            </div>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Progress</span>
                <span>1.2 / 2.0 hours</span>
              </div>
              <Progress value={60} className="h-2 bg-white/20" />
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {quickActions.map((action, index) => (
            <Card 
              key={index}
              className="hover:shadow-lg transition-all duration-200 cursor-pointer transform hover:scale-105 border-0 shadow-md"
              onClick={action.action}
            >
              <CardContent className="p-6 text-center">
                <div className={`w-12 h-12 mx-auto mb-4 rounded-full bg-${action.color}-100 flex items-center justify-center`}>
                  <action.icon className={`h-6 w-6 text-${action.color}-600`} />
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">{action.title}</h3>
                <p className="text-sm text-gray-600">{action.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Stats and Activity */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Learning Stats */}
          <div className="lg:col-span-2">
            <Card className="border-0 shadow-md">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  Learning Statistics
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  {learningStats.map((stat, index) => (
                    <div key={index} className="flex items-center space-x-3 p-4 bg-gray-50 rounded-lg">
                      <div className={`p-2 rounded-full bg-${stat.color}-100`}>
                        <stat.icon className={`h-5 w-5 text-${stat.color}-600`} />
                      </div>
                      <div>
                        <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                        <p className="text-sm text-gray-600">{stat.label}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Recent Activity */}
          <Card className="border-0 shadow-md">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                Recent Activity
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentActivity.map((activity, index) => (
                  <div key={index} className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg transition-colors">
                    <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                    <div>
                      <p className="font-medium text-gray-900 text-sm">{activity.title}</p>
                      <p className="text-xs text-gray-500">{activity.time}</p>
                    </div>
                  </div>
                ))}
              </div>
              <Button variant="outline" className="w-full mt-4" onClick={() => navigate('/progress')}>
                View All Activity
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
